using System;
using System.Text.RegularExpressions;
using System.Windows;
using EnglishTutor.Data.Models;
using EnglishTutor.Services;

namespace EnglishTutor.Windows
{
    public partial class RegisterWindow : Window
    {
        /// <summary>
        /// The username that was successfully registered.
        /// Available when DialogResult == true.
        /// </summary>
        public string RegisteredUsername { get; private set; } = string.Empty;

        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            var username = TxtUsername.Text.Trim();
            var email    = TxtEmail.Text.Trim();
            var password = PbPassword.Password;
            var confirm  = PbConfirm.Password;

            // --- Validation ---
            if (string.IsNullOrEmpty(username))
            {
                ShowError("Введите логин.");
                return;
            }
            if (username.Length < 3)
            {
                ShowError("Логин должен содержать минимум 3 символа.");
                return;
            }
            if (!Regex.IsMatch(username, @"^[a-zA-Z0-9_]+$"))
            {
                ShowError("Логин может содержать только латинские буквы, цифры и '_'.");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                ShowError("Введите пароль.");
                return;
            }
            if (password.Length < 6)
            {
                ShowError("Пароль должен содержать минимум 6 символов.");
                return;
            }
            if (password != confirm)
            {
                ShowError("Пароли не совпадают.");
                return;
            }

            // --- Registration ---
            BtnRegister.IsEnabled = false;
            BtnRegister.Content = "Регистрируем...";

            try
            {
                bool success = AuthService.CreateUser(username, password, email, UserRole.Student);
                if (success)
                {
                    RegisteredUsername = username;
                    DialogResult = true;
                    Close();
                }
                else
                {
                    ShowError("Пользователь с таким логином уже существует.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Ошибка: " + ex.Message);
            }
            finally
            {
                BtnRegister.IsEnabled = true;
                BtnRegister.Content = "Зарегистрироваться";
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ShowError(string msg)
        {
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}
