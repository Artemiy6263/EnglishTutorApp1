﻿using EnglishTutor.Data;
using EnglishTutor.Data.Models;
namespace EnglishTutor.Services
{
    public class AuthService
    {
        private static User? _currentUser;
        public static User? CurrentUser => _currentUser;
        public static bool IsAdmin => _currentUser?.Role == UserRole.Admin;
        public static bool Login(string username, string password)
        {
            using var ctx = new AppDbContext();
            var user = ctx.Users.FirstOrDefault(u => u.Username == username && u.IsActive);
            if (user == null) return false;
            if (!BCrypt.Net.BCrypt.Verify(password, user.PasswordHash)) return false;
            _currentUser = user; return true;
        }
        public static void Logout() => _currentUser = null;
        public static List<User> GetAllUsers() { using var ctx = new AppDbContext(); return ctx.Users.OrderBy(u => u.CreatedAt).ToList(); }
        public static bool CreateUser(string username, string password, string email, UserRole role)
        {
            using var ctx = new AppDbContext();
            if (ctx.Users.Any(u => u.Username == username)) return false;
            ctx.Users.Add(new User { Username=username, PasswordHash=BCrypt.Net.BCrypt.HashPassword(password), Email=email, Role=role, CreatedAt=DateTime.Now });
            ctx.SaveChanges(); return true;
        }
        public static bool UpdateUser(int userId, string email, UserRole role, bool isActive)
        {
            using var ctx = new AppDbContext();
            var user = ctx.Users.Find(userId); if (user==null) return false;
            user.Email=email; user.Role=role; user.IsActive=isActive; ctx.SaveChanges(); return true;
        }
        public static bool DeleteUser(int userId) { using var ctx = new AppDbContext(); var u=ctx.Users.Find(userId); if(u==null) return false; ctx.Users.Remove(u); ctx.SaveChanges(); return true; }
        public static bool ChangePassword(int userId, string newPassword) { using var ctx = new AppDbContext(); var u=ctx.Users.Find(userId); if(u==null) return false; u.PasswordHash=BCrypt.Net.BCrypt.HashPassword(newPassword); ctx.SaveChanges(); return true; }
    }
}
